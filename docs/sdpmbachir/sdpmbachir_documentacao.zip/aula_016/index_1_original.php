<?php

// importar a class Database e configurações

// instanciação de objeto Database

// resultados

// // ver os dados
// echo '<pre>';
// print_r($results);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP PDO - Apresentar dados</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            padding: 20px;
        }
        .caixa-cliente{
            border: 1px solid gray;
            margin: 5px;
            padding: 10px;
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <h3>DADOS DOS MEUS CLIENTES</h3>

    <!-- apresentação dos dados -->

</body>

</html>