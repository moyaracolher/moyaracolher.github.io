            </div>
        </div>
    </div>
    
    <!-- footer -->
    <div class="container-fluid fixed-bottom">
        <div class="row">
            <div class="col bg-dark text-white p-2 text-center">
                <p>Aplicação PHP PDO Contactos &copy; <?= date('Y') ?></p>
                <a href="eliminar_tudo.php">Eliminar tudo</a>
                <span class="mx-2">|</span>
                <a href="exportar_csv.php">Exportar para CSV</a>
            </div>
        </div>
    </div> 
    
    <!-- Bootstrap JS and custom JS -->
    <script src="assets/bootstrap.bundle.min.js"></script>
    <script src="assets/app.js"></script>
</body>
</html>