<?php

// APRESENTAR DADOS A PARTIR DE UMA QUERY

/*
Até agora só ficámos a conhecer o que é necessário para
ligar a nossa aplicação a uma base de dados MySQL através
de PHP Data Objects (PDO).

O importante agora é "fechar o puzzle". O que posso fazer
com isto tudo que aprendi até agora?

NOTA: ainda não falámos sobre todos os aspetos mais importantes
do PDO. A seu tempo assim faremos.

Neste vídeo vamos apresentar os resultados de uma query
no interior de uma página web.
*/