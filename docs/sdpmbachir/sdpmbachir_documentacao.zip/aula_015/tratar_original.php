<?php

// importar a class Database e configurações

// instanciação de objeto Database

// parametros

// inserir os dados do cliente

// voltar ao formulário automaticamente